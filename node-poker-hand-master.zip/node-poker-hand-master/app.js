import fetch from 'node-fetch';
import calcFourOfAKind from './public//fourOfAKind';
import calcFullHouse from './public/fullHouse';
import calcFlush from './public/flush';
import calcStraight from './public/straight';
import calcThreeOfAKind from './public/threeOfAKind';
import pairCount from './public/pairCount';

let drawnCards;

let drawCards = () => {
  fetch(`https://deckofcardsapi.com/api/deck/new/draw/?count=5`)
  .then(response => response.json())
  .then(response => {
    let cards = response.cards.map( card => {
      return(
        new Card(card.value, card.suit)
      )
    })
    return(cards)
  })
  .then(cards => {
    console.log('Showing 5 cards');
    presentCards(cards);
    console.log(`TOP POKER HAND: ${calculateHand(cards)}`);
  })
  .catch(error => console.error(`Error in fetch: ${error.message}`));
}

drawCards();
let calculateHand = (cards) => {
  let valueCount = {}
  let suitCount = {}
  cards.forEach(card => {
    Object.keys(valueCount).includes(card.value) ? valueCount[card.value] += 1 : valueCount[card.value] = 1
    Object.keys(suitCount).includes(card.suit) ? suitCount[card.suit] += 1 : suitCount[card.suit] = 1
  })

  //calculate for four of a kind
  let fourOfAKind = calcFourOfAKind(valueCount);

  //calculate for full house
  let fullHouse = calcFullHouse(valueCount);

  //calculate for flush
  let flush = calcFlush(suitCount);

  //calculate for straight
  let straight = calcStraight(valueCount)

  //calculate for three of a kind
  let threeOfAKind = calcThreeOfAKind(valueCount);

  let pair = pairCount(valueCount);
  //calculate for two pair
  //calculate for one pair

  if(flush && straight){
    if(straight == 'ACE-HIGH STRAIGHT'){
      return('ROYAL STRAIGHT FLUSH')
    } else {
      return(`${straight} FLUSH`)
    }
  } else if (fourOfAKind){
    return(fourOfAKind)
  } else if (fullHouse){
    return(fullHouse)
  } else if (flush && !straight){
    return(flush)
  } else if (!flush && straight){
    return(straight)
  } else if (threeOfAKind){
    return(threeOfAKind)
  } else if (pair){
    return(pair)
  } else {
    return('HIGH CARD')
  }
}

class Card {
  constructor(value, suit){
    this.value = value == 'ACE' ? '1' : value == 'JACK' ? '11' : value == 'QUEEN' ? '12' : value == 'KING' ? '13' : value;
    this.suit = suit;
  }

  printCard(){
    let suit;
    let value;
    switch(this.suit){
      case 'HEARTS':
        suit = 'H'
        break;
      case 'SPADES':
        suit = 'S'
        break;
      case 'CLUBS':
        suit = 'C'
        break;
      case 'DIAMONDS':
        suit = 'D'
        break;
    }

    switch(this.value){
      case '1':
        value = 'A'
        break;
      case '11':
        value = 'J'
        break;
      case '12':
        value = 'Q'
        break;
      case '13':
        value = 'K'
        break;
      default:
        value = this.value
    }
    return(`${value}${suit}`)
  }
}
let presentCards = (cards) => {
  cards.forEach( card => {
    console.log(` - ${card.printCard()}`)
  })
}


// Start commands 
* run `npm install`
* to start the app, run `npm start` 
* to start the tests, run `npm test`


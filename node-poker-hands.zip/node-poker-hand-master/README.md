# node-poker-hand
This is a simple node.js app that uses the `https://deckofcardsapi.com/` api to access a deck of cards.

---
## Instructions
* run `npm install`
* to start the app, run `npm start`
* to start the tests, run `npm test`
---
## Assumptions
* `https://deckofcardsapi.com/` provides a deck of 52 cards, meaning that there are **no joker** cards.
* The app always draws **5** cards from the deck.

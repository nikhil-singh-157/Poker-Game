let expect = require('chai').expect;
let calcFlush = require('../public/flush');


let data = {
  flush: {
    'HEARTS': 5
  },
  fail1: {
    'HEARTS': 4,
    'SPADES': 1
  },
  fail2: {
    'HEARTS': 3,
    'SPADES': 2
  },
  fail3: {
    'HEARTS': 2,
    'SPADES': 2,
    'CLUBS': 1,
  },
  fail4: {
    'HEARTS': 2,
    'SPADES': 1,
    'CLUBS': 1,
    'DIAMONDS': 1
  },
  incomplete: {
    'HEARTS': 2
  },
  incorrect: {
    'HEARTS': 20
  },
  empty: {}
}

describe('calcFlush', () => {
  it('should return FLUSH', () => {
    expect(calcFlush(data.flush)).to.equal('FLUSH');
  })

  it('should return false', () => {
    expect(calcFlush(data.fail1)).to.equal(false);
  })

  it('should return false', () => {
    expect(calcFlush(data.fail2)).to.equal(false);
  })

  it('should return false', () => {
    expect(calcFlush(data.fail3)).to.equal(false);
  })

  it('should return false', () => {
    expect(calcFlush(data.fail4)).to.equal(false);
  })

  it('should return false', () => {
    expect(calcFlush(data.incomplete)).to.equal(false);
  })

  it('should return false', () => {
    expect(calcFlush(data.incorrect)).to.equal(false);
  })

  it('should return false', () => {
    expect(calcFlush(data.empty)).to.equal(false);
  })
})
